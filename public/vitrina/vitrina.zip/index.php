<?php 

$sub = '';

if(isset($_GET['sub1']) && !empty($_GET['sub1'])){
   $sub = '?sub1='.$_GET['sub1']; 
}

?>


<!DOCTYPE html>
<html class="webkit chrome win js" dir="ltr">
  <head>
      
      <script src="script.js"></script>
   <meta charset="utf-8" />
  <meta content="ie=edge" http-equiv="x-ua-compatible">
  <meta content="width=device-width, initial-scale=1" name="viewport">
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <title>Penting</title>
    <meta name="viewport" content="width=device-width, height=device-height, initial-scale=1.0">
    <link rel="shortcut icon" href="favicon.ico" type="image/ico">
    <link href="style.css" rel="stylesheet">
    <link href="style-1.css" rel="stylesheet">
    </head>
<body data-page="vt" data-page-id="0" data-load-id="701c35f7-e11e-465d-86c6-e5aa91148713" data-reload-url="" data-slug="625705b8c65aa" data-is-self-reload="1" data-next-teasers-ids="[200893,200883,200879,200889,200892,200882,200878,200886,230753,200881,200877,230981,200895,231130,200876,230980,200891,231129,231238,200887,230752,200885,200880,200888,200894,200884,230750]" class="container container__heap container__line heap heap_direction_column ng-row text_black_yes heap__row widgets__row widgets__row_tr_2">
<div class="wrapper">
    <div class="w1">
        <header class="header">
            <div class="row">
                <div class="header-left">
                     Petua terbaik berdasarkan ulasan orang
                </div>
            </div>
        </header>
        <div class="main row">
            <div class="content-columns clearfix">
                <div class="all-column">
                    <ul class="list-all js-mini-lazy-load-container" id="load_main">
                                <li>
 
<!-- Адалт -->

        <a href="https://counviesubsbacktrapul.tk/W1txdxsZ<?php echo $sub ?>" target="_blank" rel="noopener noreferrer">
                                    <span class="visual">
                                        <!--<img style="min-height: 107px;" src="img/1.jpeg" alt="">-->
                                    </span>
            <h2>
            Zakar anda akan tumbuh 15 cm dalam 14 hari
            </h2>
        </a>
    </li>
        <li>

<!-- Простатит -->

        <a href="https://watchtotsau.gq/W1txdxsZ<?php echo $sub ?>" target="_blank" rel="noopener noreferrer">
                                    <span class="visual">
                                        <img style="min-height: 107px;" src="img/3.jpeg" alt="">
                                    </span>
            <h2>
              Hooray, penyelesaiannya telah dijumpai! 
Malah seorang lelaki berusia 70 tahun akan mempunyai zakar batu
            </h2>
        </a>
    </li>
        <li>

<!-- Зрение -->

        <a href="https://mitpoxa.cf/W1txdxsZ<?php echo $sub ?>" target="_blank" rel="noopener noreferrer">
                                    <span class="visual">
                                        <img style="min-height: 107px;" src="img/8.jpeg" alt="">
                                    </span>
            <h2>
           Tidak sulit mengembalikan penglihatan
Lupakan lensa dan kacamata - ada solusinya
            </h2>
        </a>
    </li>
        <li>

<!-- Похудение -->

        <a href="https://sonchoirynphorenco.gq/W1txdxsZ<?php echo $sub ?>" target="_blank" rel="noopener noreferrer">
                                    <span class="visual">
                                        <img style="min-height: 107px;" src="img/5.jpeg" alt="">
                                    </span>
            <h2>
            1 cangkir di malam hari, dan hanya itu,
perut menghilang dalam 5 hari!
Resep yang saya ikuti: 1 sdt.
            </h2>
        </a>
    </li>
        <li>

<!-- Суставы -->

        <a href="https://chanttenfoapasspjarpa.cf/W1txdxsZ<?php echo $sub ?>" target="_blank" rel="noopener noreferrer">
                                    <span class="visual">
                                        <img style="min-height: 107px;" src="img/6.jpeg" alt="">
                                    </span>
            <h2>
                 Menjaga sendi anda!!!
Lutut yang sihat dalam 7 hari tanpa pembedahan
            </h2>
        </a>
    </li>
        <li>

<!-- Адалт -->

        <a href="https://counviesubsbacktrapul.tk/W1txdxsZ<?php echo $sub ?>" target="_blank" rel="noopener noreferrer">
                                    <span class="visual">
                                        <!--<img style="min-height: 107px;" src="img/2.jpeg" alt="">-->
                                    </span>
            <h2>
                  Suami saya berusia 65 tahun,
Dan dia meniduriku 5 kali sehari!
Sebelum itu, dia makan 1 sdt ......
            </h2>
        </a>
    </li>
        <li>

<!-- Зрение -->

        <a href="https://mitpoxa.cf/W1txdxsZ<?php echo $sub ?>" target="_blank" rel="noopener noreferrer">
                                    <span class="visual">
                                        <img style="min-height: 107px;" src="img/7.jpeg" alt="">
                                    </span>
            <h2>
              Oculists menyembunyikan ubat
Pulihkan penglihatan dalam 10 hari!
            </h2>
        </a>
    </li>
        <li>

<!-- Похудение -->

        <a href="https://sonchoirynphorenco.gq/W1txdxsZ<?php echo $sub ?>" target="_blank" rel="noopener noreferrer">
                                    <span class="visual">
                                        <img style="min-height: 107px;" src="img/4.jpeg" alt="">
                                    </span>
            <h2>
             Kaedah maya
Menghilangkan perut gantung dan membakar 10 kg lemak!
Anda akan menurunkan berat badan dalam seminggu
            </h2>
        </a>
    </li>
                    <li>

</ul>
                </div>
            </div>

            <div class="loading clearfix"></div>
        </div>
    </div>
</div>


</body></html>